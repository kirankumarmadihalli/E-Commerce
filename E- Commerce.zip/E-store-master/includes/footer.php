<html>
    <head>
        <title>E-Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css" >
        <script type="text/javascript" src="../bootstrap/js/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
        <link rel='stylesheet' type='text/css' href="../style.css">
    </head>
    <body>
        <footer >
            <div class="container">
            <div class="row">
                <div class="col-xs-4">
                    <h3>Information</h3>
                    <a href="about.php">About Us</a><br>
                    <a href="contact.php" >Contact Us</a>
                </div>
                <div class="col-xs-4">
                    <h3>My Account</h3>
                    <a href="signup.php">Sign Up</a><br>
                    <a data-target="#mymodal" data-toggle="modal">Login</a>
                </div>
                <div class="col-xs-4">
                    <h3>Contact Us</h3>
                    <p style="color: #9d9d9d">Contact +91-123-0000000</p>
                </div>
            </div>
            </div><br>
        </footer>
    </body>
</html>